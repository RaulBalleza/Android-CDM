package tuchingadamadre.maganda.nuno.marco.listview_sppinner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView LV1, LV2;
    Spinner SP1, SP2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Array of Months acting as a data pump
        String[] objects = { "January", "Feburary", "March", "April", "May",
                "June", "July", "August", "September", "October", "November","December" };

        // Por defecto utiliza una configuración predeterminada
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1 ,objects);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Es posibile substituir por colores chirriantes que el usuario desee
        //ArrayAdapter adapter = new ArrayAdapter(this,R.layout.fila_spinner ,objects);
        //adapter.setDropDownViewResource(R.layout.fila_spinner_despega);


        SP1=(Spinner) findViewById(R.id.spinner);
        SP2=(Spinner) findViewById(R.id.spinner2);
        LV1=(ListView) findViewById(R.id.listView);
        LV2=(ListView) findViewById(R.id.listView2);


        SP1.setAdapter(adapter);
        SP2.setAdapter(adapter);
        LV1.setAdapter(adapter);
        LV2.setAdapter(adapter);

        SP1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Spinner 1" + parent.getItemAtPosition(position).toString() + "Elemento:[" + position + "]", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        SP2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),"Spinner 2"+parent.getItemAtPosition(position).toString()+"Elemento:["+position+"]",Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        LV1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "ListView 1" + parent.getItemAtPosition(position).toString() + "Elemento:[" + position + "]", Toast.LENGTH_SHORT).show();
            }
        });

        LV2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),"ListView 2"+parent.getItemAtPosition(position).toString()+"Elemento:["+position+"]",Toast.LENGTH_SHORT).show();
            }
        });


    }
}
